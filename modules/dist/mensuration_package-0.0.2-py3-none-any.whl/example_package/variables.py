half = 1/2
π = 22/7

#Commonly used Functions
def root(x):
    return x ** 0.5

def sq(x):
    return x ** 2

def cube(x):
    return x ** 3